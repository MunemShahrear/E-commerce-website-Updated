<?php
include("../database/db.php");
include('../function/functions.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Affirmative</title>
<link rel="stylesheet" href="../style/style.css" media="all" />


</head>


<body>
		<!--main wraper-->
	<div class="main_wraper">
			
            
            
            <!--header wraper-->
		<div class="header_wraper"> 
      <img src="../photos/LOGO.png" width="172" height="85" style="float:left; padding-left:30px;" >
       
</div>
        
        
        
       
        
        <!--contain wraper-->
        
        
<div class="content_wraper">

		<div id="headline">Admin Option</div>
    	<div id="headline2"></div>
    
	<div id="product_page">
  		<div id="products_box">
        
<br/><br />
<a href="insert_product.php"<div align="center">            <input type="button" class="login_btn" name="signin" value="Insert New Product"/></html></a><br /><br/><br /><br/>
<a href="update_page.php"<div align="center">            <input type="button" class="login_btn" name="signin" value="Update Product"/></a><br /><br/><br /><br/>
<a href="delete_product.php"<div align="center">            <input type="button" class="login_btn" name="signin" value="Delete Product"/></a>
	
        </div>
        
        
      </div>
     </div>  
       
</div>

        
      </div> 
       
        <!--footer wraper-->
<div class="footer">
	<h1 style="color:#FFF;
	padding-top:30 px; text-align:left;
	font-size:12px;"> 2017-All copyright&copy; reserve by Himel </h1> <a href="admin_option.php"><h2 style=" font-size:12px; margin-right:20px; margin-top:5 px; color:
    #CCC; float:right">Top</h2></a>

</div>

</div>


</body>
</html>