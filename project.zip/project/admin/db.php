<?php


	
$himel=mysqli_connect("localhost","root","","affirmative");
?>